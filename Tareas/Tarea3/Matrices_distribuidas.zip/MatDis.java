import java.net.Socket;
import java.net.ServerSocket;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.lang.Thread;
import java.nio.ByteBuffer;

class MatDis{
    
    static Object lock = new Object();
    static int N = 4, i = 0, j = 0, k=0;
    // Declaramos matrices originales
    static int[][] A;
    static int[][] B;
    static int[][] C;
    

    static class Worker extends Thread{
        Socket conexion;

        Worker(Socket conexion){
        
            this.conexion = conexion;
        }
        
        public void run(){
           
            try {
                // Declaramos la matriz A1 y A2, B1, B2
                int[][] A1 = new int[N/2][N];
                int[][] A2 = new int[N][N];
                int[][] B1 = new int[N/2][N];
                int[][] B2 = new int[N][N];
                //Creamos la transmisión de entrada para recibir las matrices
                DataInputStream entrada = new DataInputStream(conexion.getInputStream());                
                // Creamos la transmisión de salida para enviar la matrices 
                DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
            
                // Recibe en la variable x el nodo 
                int x = entrada.readInt();
                // Paso 2 - 9 Enviar las matrices A1, B1, A2 Y B2 a los nodos
                if (x == 1){

                    for(i = 0; i < (N/2); i++){
                        for(j = 0; j < N; j++){
                            A1 [i][j] = A [i][j];
                            B1 [i][j] = B [i][j];
                            salida.writeInt(A1[i][j]); // Enviar la matriz A1 al nodo 1
                            salida.writeInt(B1[i][j]); // Enviar la matriz B1 al nodo 1
                        }
                    }
                     
                    //Mensaje del nodo 0: 
                    System.out.println("\nSe conecto el nodo 1.\nEnvio la matriz A1 al nodo 1: ");
                    imprimir_matriz(A1,N/2,N);
                    System.out.println("\nEnvio la matriz B1 al nodo 1: ");
                    imprimir_matriz(B1,N/2,N);
                    // for(i = 0; i < (N/2); i++){
                    //     for(j = 0; j < N; j++){
                    //         B1 [i][j] = B [i][j];
                    //         salida.writeInt(B1[i][j]); // Enviar la matriz B1 al nodo 1.
                    //     }
                    // }
                } else if (x == 2){

                    for(i = 0; i < (N/2); i++){
                        for(j = 0; j < N; j++){
                            A1 [i][j] = A [i][j];
                            salida.writeInt(A1[i][j]); // Enviar la matriz A1 al nodo 2.
                        }
                    }
                     
                    for(i = (N/2); i < N; i++){
                        for(j = 0; j < N; j++){
                            B2 [i][j] = B [i][j];
                            salida.writeInt(B2[i][j]); // Enviar la matriz B2 al nodo 2.
                        }
                    }
                     
                    //Mensaje del nodo 0: 
                    System.out.println("\nSe conecto el nodo 2.\nEnvio la matriz A1 al nodo 2: ");
                    imprimir_matriz(A1,N/2,N);
                    System.out.println("\nEnvio la matriz B2 al nodo 2: ");
                    imprimir_matriz(B2,N,N);
                } else if (x == 3){
                
                    for(i = (N/2); i < N; i++){
                        for(j = 0; j < N;j++){
                            A2 [i][j] = A [i][j];
                            salida.writeInt(A2[i][j]); // Enviar la matriz A2 al nodo 3.
                        }
                    }       
                     
                    for(i = 0; i < (N/2); i++){
                        for(j = 0; j < N; j++){
                            B1 [i][j] = B [i][j];
                            salida.writeInt(B1[i][j]); // Enviar la matriz B1 al nodo 3.
                        }
                    }
                     
                    //Mensaje del nodo 0: 
                    System.out.println("\nSe conecto el nodo 3.\nEnvio la matriz A2 al nodo 3: ");
                    imprimir_matriz(A2,N,N);
                    System.out.println("\nEnvio la matriz B1 al nodo 3: ");
                    imprimir_matriz(B1,N/2,N);
                } else if (x == 4){
                    
                    for(i = (N/2); i < N; i++){
                        for(j = 0; j < N;j++){
                            A2 [i][j] = A [i][j];
                            B2 [i][j] = B [i][j];
                            salida.writeInt(B2[i][j]); // Enviar la matriz B2 al nodo 4.
                            salida.writeInt(A2[i][j]); // Enviar la matriz A2 al nodo 4.
                        }
                    }    
                     
                    // for(i = (N/2); i < N; i++)
                    //     for(j = 0; j < N; j++)
                    //         B2 [i][j] = B [i][j];
                    //         salida.writeInt(B2[i][j]); // Enviar la matriz B2 al nodo 4.
                    //Mensaje del nodo 0: 
                    System.out.println("\nSe conecto el nodo 4.\nEnvio la matriz A2 al nodo 4: ");
                    imprimir_matriz(A2,N,N);
                    System.out.println("\nEnvio la matriz B2 al nodo 4: ");
                    imprimir_matriz(B2,N,N);

                }
                // for(i = 0; i < (N/2); i++)
                //     for(j = 0; j < N; j++)
                //         A1 [i][j] = A [i][j];
                //         salida.writeInt(A1[i][j]); // Enviar la matriz A1 a los nodos.

                // for(i = 0; i < (N/2); i++)
                //     for(j = 0; j < N; j++)
                //         B1 [i][j] = B [i][j];
                //         salida.writeInt(B1[i][j]); // Enviar la matriz B1 a los nodos.

                // for(i = (N/2); i < N; i++)
                //     for(j = 0; j < N;j++)
                //         A2 [i][j] = A [i][j];
                //         salida.writeInt(A2[i][j]); // Enviar la matriz A2 a los nodos.
                
                // for(i = (N/2); i < N; i++)
                //     for(j = 0; j < N; j++)
                //         B2 [i][j] = B [i][j];
                //         salida.writeInt(B2[i][j]); // Enviar la matriz B2 a los nodos.

                // Depende el nodo, recibe dentro de un bloque synchronized mediante el objeto "lock":
                synchronized(lock){
                    
                    if(x == 1){             // 10. Recibe la matriz C1 del nodo 1

                        int[][] C1 = new int[N/2][N/2];
                        for(i = 0; i < (N/2); i++){
                            for(j = 0; j < (N/2); j++){
                                C1[i][j] = entrada.readInt(); // Lo que recibe lo asigna al bloque C1
                                C[i][j] = C1[i][j]; // El bloque lo coloca en la matriz C (original)
                            }
                        }
                         
                        // Mensaje del nodo 0.
                        System.out.println("\nRecibi la matriz C1 del nodo 1");
                        imprimir_matriz(C,N,N);

                    }else if (x == 2){      // 11. Recibe la matriz C2 del nodo 2
                        
                        int[][] C2 = new int[N/2][N];
                        for(i = 0; i < (N/2); i++){
                            for(j = (N/2); j < N; j++){
                                C2[i][j] = entrada.readInt();
                                C[i][j] = C2[i][j];
                            }
                        }    
                         
                        
                        // Mensaje del nodo 0.
                        System.out.println("\nRecibi la matriz C2 del nodo 2");
                        imprimir_matriz(C,N,N);
                    }else if (x == 3){      // 12. Recibe la matriz C3 del nodo 3

                        int[][] C3 = new int[N][N/2];
                        for(i = (N/2); i < N; i++){
                            for(j = 0; j < (N/2); j++){
                                C3[i][j] = entrada.readInt();
                                C[i][j] = C3[i][j];
                            }
                        }        
                         
                        // Mensaje del nodo 0.
                        System.out.println("\nRecibi la matriz C3 del nodo 3");
                        imprimir_matriz(C,N,N);
                    }else if (x == 4){      // 13. Recibe la matriz C4 del nodo 4

                        int[][] C4 = new int[N][N];
                        for(i = (N/2); i < N; i++){
                            for(j = (N/2); j < N; j++){
                                C4[i][j] = entrada.readInt();
                                C[i][j] = C4[i][j];
                            }
                        }
                         
                        // Mensaje del nodo 0.
                        System.out.println("\nRecibi la matriz C4 del nodo 4");
                        imprimir_matriz(C,N,N);

                    }

                }            
                System.out.print("\nTermina conexion con el nodo: " + x);

                entrada.close();
                salida.close();
                conexion.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
  
    public static void main(String[] args) throws Exception {
        if (args.length != 1){
        System.err.println("Uso:");
        System.err.println("java MatDis <nodo>");
        System.exit(0);
        }
        int nodo = Integer.valueOf(args[0]);

        if (nodo == 0){
            A = new int[N][N];
            B = new int[N][N];
            C = new int[N][N];
            // 1.- Inicializando las matrices
            for (i = 0; i < N; i++){
                for (j = 0; j < N; j++){
                    A[i][j] = 2 * i + j;
                    B[i][j] = 2 * i - j;
                    C[i][j] = 0;
                    
                }
            }
            // imprimiendo A
            System.out.println("\nMatriz A: ");
            imprimir_matriz(A,N,N);
            // imprimiendo la matriz B
            System.out.println("\nMatriz B (Original): ");
            imprimir_matriz(B,N,N);          
            // transpone la matriz B, la matriz traspuesta queda en B
            for (i = 0; i < N; i++){
                for (j = 0; j < i; j++){
                    int t = B[i][j];
                    B[i][j] = B[j][i];
                    B[j][i] = t;
                }
            }
            // imprimiendo la matriz B
            System.out.println("\nMatriz B 'Transpuesta': ");
            imprimir_matriz(B,N,N);   

            System.out.println("\nEsperando por conexiones...");
            // creamos el servidor 
            ServerSocket servidor = new ServerSocket(5000);

            Worker[] w = new Worker[4];
            
            int s = 0;
            while (s != 4){
    
                Socket conexion = servidor.accept();
                w[s] = new Worker(conexion);
                w[s].start();
                s++;

            }
            
            int z = 0;
            while (z != 4){
                w[z].join();
                z++;
            }
            System.out.println("\nHe dejado de recibir concexiones... ");
            
            servidor.close();
            // 14. Calcular el checksum de la matriz C.
            int checksum = 0;
            for( i = 0; i < N; i++){
                for( j = 0; j < N; j++){
                    checksum += C[i][j];
                }
            }// 15. Desplegar el checksum de la matriz C.
            System.out.println("El check sum es: " + checksum + " ");
            // 16. Si N=4 entonces desplegar la matriz C=AxB
            if (N == 4){
                System.out.println("Desplegando matriz C = A x B");
                for( i = 0; i < N; i++) {
                    for( j = 0; j < N; j++) {
                        System.out.print(C[i][j] + " ");
                    } 
                    System.out.println("");
                }
        
                System.out.println("");
            }
        
        }else{
            // Declaramos las matrices donde se recibirán las originales
            int[][] rA = new int[N/2][N];
            int[][] rB = new int[N/2][N];
            // declaramos la matriz en donde guardaremos el producto de A1 x B1
            int[][] pC = new int[N/2][N/2];
            if(nodo == 1){
                // creamos la concexión con el socket
                Socket conexion = new Socket("localhost", 5000);
                // Creamos las transmisiones de entrada y salida
                DataInputStream entrada = new DataInputStream(conexion.getInputStream());
                DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                // Enviamos al servidor (nodo 0) el numero de nodo en el que estamos
                salida.writeInt(nodo);
                 
                
                for (i = 0; i < (N/2); i++){
                    for (j = 0; j < N; j++){
                        // 1. Recibir del nodo 0 la matriz A1.
                        rA[i][j] = entrada.readInt(); 
                         // 2. Recibir del nodo 0 la matriz B1.
                        rB[i][j] = entrada.readInt(); 
                
                    }
                }
                 

                //Mensaje del nodo 1
                System.out.println("\nRecibi matriz A1 del nodo 0: ");
                imprimir_matriz(rA,N/2,N);
                System.out.println("\nRecibi matriz B1 del nodo 0: ");
                imprimir_matriz(rB,N/2,N);
                // 3. Realizar el producto C1=A1xB1.
                for ( i = 0; i < (N/2); i++){
                    for (j = 0; j < (N/2); j++){
                        for (k = 0; k < N; k++){
                            pC[i][j] += rA[i][k] * rB[j][k];
                        }
                    }
                }    
                // 4. Enviar la matriz C1 al nodo 0.
                for( i = 0; i < (N / 2); i++){
                    for( j = 0; j < (N / 2); j++){  
                        salida.writeInt(pC[i][j]);
                    }
                }
                 
                System.out.println("\nEnvio la matriz C1 al nodo 0: ");
                imprimir_matriz(pC,N/2,N/2);
                // cerramos las transmisiones de entrada, salida y la conexión
                entrada.close();
                salida.close();
                conexion.close();
            }else if (nodo == 2){
                // creamos la concexión con el socket
                Socket conexion = new Socket("localhost", 5000);
                // Creamos las transmisiones de entrada y salida
                DataInputStream entrada = new DataInputStream(conexion.getInputStream());
                DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                // Enviamos al servidor (nodo 0) el numero de nodo en el que estamos
                salida.writeInt(nodo);
                 
                
                for(i = 0; i < (N/2); i++){
                    for(j = 0; j < N; j++){
                        // 1. Recibir del nodo 0 la matriz A1.
                        rA[i][j] = entrada.readInt();
                        // 2. Recibir del nodo 0 la matriz B2.
                        rB[i][j] = entrada.readInt();
                    }    
                }
                 
                //Mensaje del nodo 2
                System.out.println("\nRecibi matriz A1 del nodo 0: ");
                imprimir_matriz(rA,N/2,N);
                System.out.println("\nRecibi matriz B2 del nodo 0: ");
                imprimir_matriz(rB,N/2,N);
                // 3. Realizar el producto C2=A1xB2.
                for ( i = 0; i < (N/2); i++){
                    for (j = 0; j < (N/2); j++){
                        for (k = 0; k < N; k++){
                            pC[i][j] += rA[i][k] * rB[j][k];
                        }
                    }
                }
                // 4. Enviar la matriz C2 al nodo 0.
                for( i = 0; i < (N / 2); i++){
                    for( j = 0; j < (N / 2); j++){
                        salida.writeInt(pC[i][j]);               
                    }
                }
                 
                System.out.println("\nEnvio la matriz C2 al nodo 0: ");
                imprimir_matriz(pC,N/2,N/2);
                // cerramos las transmisiones de entrada, salida y la conexión
                entrada.close();
                salida.close();
                conexion.close();
            }else if (nodo == 3){
                // creamos la concexión con el socket
                Socket conexion = new Socket("localhost", 5000);
                // Creamos las transmisiones de entrada y salida
                DataInputStream entrada = new DataInputStream(conexion.getInputStream());
                DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                // Enviamos al servidor (nodo 0) el numero de nodo en el que estamos
                salida.writeInt(nodo);
                 
                
                for(int i = 0; i < (N/2); i++){
                    for(int j = 0; j < N; j++){
                        // 1. Recibir del nodo 0 la matriz A2.
                        rA[i][j] = entrada.readInt();
                        // 2. Recibir del nodo 0 la matriz B1.
                        rB[i][j] = entrada.readInt();
                    }
                }
                 
                //Mensaje del nodo 3
                System.out.println("\nRecibi matriz A2 del nodo 0: ");
                imprimir_matriz(rA,N/2,N);
                System.out.println("\nRecibi matriz B1 del nodo 0: ");
                imprimir_matriz(rB,N/2,N);

                // 3. Realizar el producto C3=A2xB1.
                for ( i = 0; i < (N/2); i++){
                    for (j = 0; j < (N/2); j++){
                        for (k = 0; k < N; k++){
                            pC[i][j] += rA[i][k] * rB[j][k];
                        }
                    }
                }
                // 4. Enviar la matriz C3 al nodo 0.
                for(int i = 0; i < (N/2); i++){
                    for(int j = 0; j < (N/2); j++){
                        salida.writeInt(pC[i][j]);
                    }
                }
                 
                System.out.println("\nEnvio la matriz C3 al nodo 0: ");
                imprimir_matriz(pC,N/2,N/2);

                // cerramos flujos de entrada, salida y la conexión.
                entrada.close();
                salida.close();
                conexion.close();
            }else if (nodo == 4){
                // creamos la concexión con el socket
                Socket conexion = new Socket("localhost", 5000);
                // Creamos las transmisiones de entrada y salida
                DataInputStream entrada = new DataInputStream(conexion.getInputStream());
                DataOutputStream salida = new DataOutputStream(conexion.getOutputStream());
                // Enviamos al servidor (nodo 4) el numero de nodo en el que estamos
                salida.writeInt(nodo);
                 
                
                for(int i = 0; i < (N/2); i++){
                    for(int j = 0; j < N; j++){
                        // 1. Recibir del nodo 0 la matriz A2.
                        rA[i][j] = entrada.readInt();
                        // 2. Recibir del nodo 0 la matriz B2.
                        rB[i][j] = entrada.readInt();
                    }
                }
                 
                //Mensaje del nodo 3
                System.out.println("\nRecibi matriz A2 del nodo 0: ");
                imprimir_matriz(rA,N/2,N);
                System.out.println("\nRecibi matriz B2 del nodo 0: ");
                imprimir_matriz(rB,N/2,N);

                // 3. Realizar el producto C4=A2xB2.
                for ( i = 0; i < (N/2); i++){
                    for (j = 0; j < (N/2); j++){
                        for (k = 0; k < N; k++){
                            pC[i][j] += rA[i][k] * rB[j][k];
                        }
                    }
                }
                // 4. Enviar la matriz C4 al nodo 0.
                for( i = 0; i < (N/2); i++){
                    for( j = 0; j < (N/2); j++){
                        salida.writeInt(pC[i][j]);
                    }
                }
                 
                System.out.println("\nEnvio la matriz C4 al nodo 0: ");
                imprimir_matriz(pC,N/2,N/2);
                // Cerramos los flujos de entrada y salida, así como la conexión
                entrada.close();
                salida.close();
                conexion.close();
            }
                     
        }
    }
    // Método imprimir matriz, recibe una matriz a imprimir y sus filas y columnas a imprimir
    private static void imprimir_matriz(int[][] m, int filas, int columnas) {
        for (i = 0; i< filas; i++){
            for (j = 0; j < columnas; j++){
                System.out.print(m[i][j] + " ");
            }
            System.out.println("");
        }
    }
}